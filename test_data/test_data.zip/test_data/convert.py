import numpy as np
from PIL import Image
import os

def convert_mnist_singlefile_to_image(filepath, output_dir="mnist_images"):
    """
    Converts MNIST pixel data (binary strings, 784 lines per file + 1 label line)
    into a 28x28 grayscale PNG image with the same base filename.

    - First 784 lines = pixel data
    - Last line (785th) = digit label → ignored
    - Ignores last 8 bits of each pixel's binary string
    """
    try:
        with open(filepath, "r") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        print(f"Error: File not found at {filepath}")
        return

    if len(lines) != 785:
        print(f"Warning: {filepath} should contain 785 lines (found {len(lines)})")

    # Use only first 784 lines (pixel data)
    pixel_lines = lines[:784]

    os.makedirs(output_dir, exist_ok=True)

    # Convert binary strings to integers, ignoring last 8 bits
    pixels = [int(p[:-8], 2) if len(p) > 8 else 0 for p in pixel_lines]

    # Scale values to 0–255 for grayscale
    max_val = max(pixels) if max(pixels) > 0 else 1
    pixels = [int(val * 255 / max_val) for val in pixels]

    # Reshape into 28x28
    image_array = np.array(pixels, dtype=np.uint8).reshape(28, 28)

    # Create grayscale image
    img = Image.fromarray(image_array, mode="L")

    # Get base filename without extension
    base_name = os.path.splitext(os.path.basename(filepath))[0]

    # Save with same name but .png extension
    image_filename = os.path.join(output_dir, f"{base_name}.png")
    img.save(image_filename)

    print(f"Saved {image_filename}")


# if __name__ == "__main__":
#     convert_mnist_singlefile_to_image("test_data_3599.txt", "mnist_images")


if __name__ == "__main__":
    # Loop through all files test_data_0000.txt to test_data_9999.txt
    for i in range(10000):  # 0 → 9999
        filename = f"test_data_{i:04d}.txt"  # zero-padded to 4 digits
        convert_mnist_singlefile_to_image(filename, "mnist_images")



    # If you want to process all .txt files in a folder:
    # import glob
    # for txt_file in glob.glob("*.txt"):
    #     convert_mnist_singlefile_to_image(txt_file, "mnist_images")

